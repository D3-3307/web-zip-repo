self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0f8ed33c69af5ced70c224ef1f399faa",
    "url": "/index.html"
  },
  {
    "revision": "4c0eb92218406ad63655",
    "url": "/static/css/main.81b8d7f6.chunk.css"
  },
  {
    "revision": "b78f80de12e6ae06cd53",
    "url": "/static/js/2.023fca99.chunk.js"
  },
  {
    "revision": "501f379103cbfcb5ff11211dd39a28a2",
    "url": "/static/js/2.023fca99.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4c0eb92218406ad63655",
    "url": "/static/js/main.f7a91e9a.chunk.js"
  },
  {
    "revision": "7c8693538bb51a957e90",
    "url": "/static/js/runtime-main.1022905a.js"
  }
]);